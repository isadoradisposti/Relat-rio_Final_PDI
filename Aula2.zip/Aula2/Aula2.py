import numpy as np
import matplotlib.pyplot as plt

colunas = 30
linhas = 10
image_matriz = np.zeros([linhas, colunas])
print(image_matriz.shape)

#I
image_matriz[0,1]=255
image_matriz[0,2]=255
image_matriz[0,3]=255
image_matriz[1,2]=255
image_matriz[2,2]=255
image_matriz[3,2]=255
image_matriz[4,2]=255
image_matriz[5,2]=255
image_matriz[6,2]=255
image_matriz[7,2]=255
image_matriz[8,2]=255
image_matriz[9,1]=255
image_matriz[9,3]=255
image_matriz[9,2]=255

#D
image_matriz[0,5]=255
image_matriz[1,5]=255
image_matriz[2,5]=255
image_matriz[3,5]=255
image_matriz[4,5]=255
image_matriz[5,5]=255
image_matriz[6,5]=255
image_matriz[7,5]=255
image_matriz[8,5]=255
image_matriz[9,5]=255
image_matriz[0,6]=255
image_matriz[1,7]=255
image_matriz[2,8]=255
image_matriz[3,8]=255
image_matriz[4,8]=255
image_matriz[5,8]=255
image_matriz[6,8]=255
image_matriz[7,8]=255
image_matriz[9,6]=255
image_matriz[8,7]=255

#B
image_matriz[0,10]=255
image_matriz[1,10]=255
image_matriz[2,10]=255
image_matriz[3,10]=255
image_matriz[4,10]=255
image_matriz[5,10]=255
image_matriz[6,10]=255
image_matriz[7,10]=255
image_matriz[8,10]=255
image_matriz[9,10]=255
image_matriz[0,11]=255
image_matriz[1,12]=255
image_matriz[2,13]=255
image_matriz[3,13]=255
image_matriz[4,12]=255
image_matriz[5,13]=255
image_matriz[6,13]=255
image_matriz[7,13]=255
image_matriz[9,11]=255
image_matriz[8,12]=255
image_matriz[4,11]=255

#D
image_matriz[0,15]=255
image_matriz[1,15]=255
image_matriz[2,15]=255
image_matriz[3,15]=255
image_matriz[4,15]=255
image_matriz[5,15]=255
image_matriz[6,15]=255
image_matriz[7,15]=255
image_matriz[8,15]=255
image_matriz[9,15]=255
image_matriz[0,16]=255
image_matriz[1,17]=255
image_matriz[2,18]=255
image_matriz[3,18]=255
image_matriz[4,18]=255
image_matriz[5,18]=255
image_matriz[6,18]=255
image_matriz[7,18]=255
image_matriz[9,16]=255
image_matriz[8,17]=255

#S
image_matriz[0,21]=255
image_matriz[0,22]=255
image_matriz[0,23]=255
image_matriz[0,20]=255
image_matriz[1,20]=255
image_matriz[2,20]=255
image_matriz[3,20]=255
image_matriz[4,20]=255
image_matriz[4,21]=255
image_matriz[4,22]=255
image_matriz[4,23]=255
image_matriz[4,23]=255
image_matriz[5,23]=255
image_matriz[6,23]=255
image_matriz[7,23]=255
image_matriz[8,23]=255
image_matriz[9,23]=255
image_matriz[9,23]=255
image_matriz[9,22]=255
image_matriz[9,21]=255
image_matriz[9,20]=255









plt.imshow(image_matriz,cmap='gray')
plt.show()