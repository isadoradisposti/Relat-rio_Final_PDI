import numpy as np
import matplotlib.pyplot as plt
import cv2
from mpl_toolkits.mplot3d import Axes3D

# Função para calcular e plotar o espectro 3D
def plotar_espectro_3D(imagem, titulo):
    # Calcule a Transformada de Fourier 2D da imagem
    transformada_fourier = np.fft.fft2(imagem)

    # Calcule o espectro 2D
    espectro_2D = np.fft.fftshift(transformada_fourier)

    # Calcule o espectro de magnitude
    espectro_magnitude = np.abs(espectro_2D)

    # Crie uma grade de coordenadas para o espectro 3D
    x = np.fft.fftshift(np.fft.fftfreq(imagem.shape[1]))
    y = np.fft.fftshift(np.fft.fftfreq(imagem.shape[0]))
    X, Y = np.meshgrid(x, y)

    # Plote o espectro 3D
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    ax.set_title('Espectro 3D - ' + titulo)
    ax.plot_surface(X, Y, np.log(1 + espectro_magnitude), cmap='viridis')

    plt.show()

# Carregue a imagem de sua escolha (por exemplo, 'imgCar')
imgCar = cv2.imread("./imagem/carro.jpg", cv2.IMREAD_GRAYSCALE)
imgLen = cv2.imread("./imagem/woman.jpg", cv2.IMREAD_GRAYSCALE)
imgNS = cv2.imread("./imagem/men.jpg", cv2.IMREAD_GRAYSCALE)
imgPeriodic = cv2.imread("./imagem/olho.jpg", cv2.IMREAD_GRAYSCALE)
imgSinc = cv2.imread("./imagem/quadrado_branco.jpg", cv2.IMREAD_GRAYSCALE)

# Chamada da função para cada imagem
plotar_espectro_3D(imgCar, "imgCarro")
plotar_espectro_3D(imgLen, "imgLena")
plotar_espectro_3D(imgNS, "imgHomem")
plotar_espectro_3D(imgPeriodic, "imgOlho")
plotar_espectro_3D(imgSinc, "imgQuadrado_Branco")