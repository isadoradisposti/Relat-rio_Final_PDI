import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

def main():
    image_pillow = Image.open("C:/Users/isado/OneDrive/Área de Trabalho/Projeto imagem/image/lena_gray_512_salt_pepper.tif")
    f_image_nd = np.array(image_pillow)
    g_image_nd = np.zeros(f_image_nd.shape)
    i_image_nd = np.zeros(f_image_nd.shape)

    #Neighborhood operation (Operação por Vizinhança)
    l = f_image_nd.shape[0]
    c = f_image_nd.shape[1]
    k = 2 #kerenel_size
    print(f_image_nd[0:5,0:5])
    for x in range(k, l-k): #linhas
        for y in range(k, c-k): #colunas
            s_xy = f_image_nd[x-k:x+k+1, y-k:y+k+1]
            g_image_nd[x,y] = np.mean(s_xy).astype(int)
            #print('janela')
            #print(s_xy)
            
         

    # create two colums plot
    fig = plt.figure()
    plt1 = fig.add_subplot(1,2,1)
    plt2 = fig.add_subplot(1,2,2)
    plt3 = fig.add_subplot(1,1,3)
    plt1.set_title("Original Image")
    plt2.set_title("Filtered Image")
    plt3.set_title("Filtered Image Good")

    plt1.imshow(f_image_nd, cmap='gray')
    plt2.imshow(g_image_nd, cmap='gray', vmin=0, vmax=255)
    plt3.imshow(i_image_nd, cmap='gray', vmin=0, vmax=255)
    plt.show()

if __name__ == "__main__":
    main()