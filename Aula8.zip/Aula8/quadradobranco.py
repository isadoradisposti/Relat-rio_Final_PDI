import numpy as np
import matplotlib.pyplot as plt
import cv2

# Criando uma imagem preta de 512x512
imagem = np.zeros((512, 512), dtype=np.uint8)

# Adicionando um quadrado branco no meio da imagem
cv2.rectangle(imagem, (204, 204), (308, 308), 255, -1)

# Visualizando a imagem
plt.imshow(imagem, cmap='gray')
plt.title("Imagem Original")
plt.show()